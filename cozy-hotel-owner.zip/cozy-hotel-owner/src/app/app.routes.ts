import { Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component'; 
import { HotelProfileComponent } from './hotel-profile/hotel-profile.component';// ✅ must match your path
import { RoomManagementComponent } from './room-management/room-management.component';
import { ManageBookingsComponent } from './manage-bookings/manage-bookings.component';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { SearchHotelsComponent } from './search-hotels/search-hotels.component';
import { MyBookingsComponent } from './my-bookings/my-bookings.component';
//import { BookHotelComponent } from './book-hotel/book-hotel.component';
//import { MyBookingsComponent } from './my-bookings/my-bookings.component';

export const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' }, // default route
  { path: 'login', component: LoginComponent },         // ✅ this is required
  { path: 'dashboard', component: DashboardComponent },
  { path: 'profile', component: HotelProfileComponent },
  {path: 'rooms',component:RoomManagementComponent},
  {path: 'bookings',component:ManageBookingsComponent},
  { path: 'user/dashboard', component: UserDashboardComponent},
  {path: 'user/profile', component: UserProfileComponent },
  {path: 'user/search',component:SearchHotelsComponent},
  //{path:'user/bookings',component:BookHotelComponent},
  { path: 'user/bookings', component: MyBookingsComponent }
];
